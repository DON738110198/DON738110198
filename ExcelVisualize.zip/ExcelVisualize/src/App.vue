<template>
  <div>
    <div class="line"></div>
    <el-menu
      class="el-menu-demo"
      mode="horizontal"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b"
    >
      <!-- 首页对功能做一些简单的介绍 -->
      <!-- 这是上方的导航条 -->
      <!-- 点击对应的框就会触发对应的函数，触发路由功能 -->
      <el-menu-item index="1" @click="toIndex()"
        ><i class="el-icon-s-help"></i>首页</el-menu-item
      >
      <el-menu-item index="3" @click="toData()"
        ><i class="el-icon-upload2"></i>
        <i class="el-icon-download"></i>导入/导出数据</el-menu-item
      >
      <el-submenu index="2" :disabled="isDisabled">
        <template slot="title"
          ><i class="el-icon-data-line"></i>数据可视化</template
        >
        <el-menu-item index="2-2" @click="toZhe()"
          ><i class="el-icon-data-line"></i>折线图/柱状图</el-menu-item
        >
        <el-menu-item index="2-3" @click="toBing()"
          ><i class="el-icon-help"></i>饼图</el-menu-item
        >
      </el-submenu>
    </el-menu>
    <!--  -->
    <!-- 对 MyData 组件做切换走时不销毁的特殊处理，因为其包含着生成的 excel 表格 -->
    <keep-alive include="MyData">
      <!-- 做路由处理 -->
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {
      isDisabled: true,
    };
  },

  methods: {
    // 做对应的路由处理
    toIndex() {
      this.$router.replace({
        name: "MyIndex",
      });
    },
    toData() {
      this.$router.replace({
        name: "MyData",
      });
    },
    toZhe() {
      this.$router.replace({
        name: "MyZhe",
      });
    },
    toBing() {
      this.$router.replace({
        name: "MyBing",
      });
    },
    //
    // 这个函数要传递给子组件 MyData 进而来修改这里的IsDisabled 属性
    changeIsDisabled() {
      this.isDisabled = false;
    },
  },
};
</script>

<style scoped lang="less"></style>
