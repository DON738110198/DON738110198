<template>
  <div>
    <el-divider></el-divider>
    <div ref="chart1" style="width: 100%; height: 600px"></div>

    <el-divider></el-divider>
    <div ref="chart2" style="width: 100%; height: 600px"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      MyData: [],
      idData: [],
      xAxisData: [],
    };
  },
  mounted() {
    // 从缓存中获取用户上传的 excel 表格的数据
    const MyData = JSON.parse(sessionStorage.getItem("MyData"));
    // 将这个数据保存到这个 vue 文件的data中
    this.MyData = MyData;
    // 将这些数据处理一下，筛选出来便于制作表格的部分
    this.possessData();
    this.getEchartData1();
    this.getEchartData2();
  },
  methods: {
    // 制作第一个图表
    getEchartData1() {
      const echarts = this.$echarts;
      // 先获取想要放置图表的 Dom 元素
      const chart = this.$refs.chart1;
      var MyData = this.MyData;
      var idData = this.idData;
      var xAxisData = this.xAxisData;

      // 处理完data数据发现配置项也要处理一下才行
      // 要动态的根据 data 的个数来调整配置项
      var series = [];
      const len = idData.length;
      for (let i = 0; i < len; i++) {
        // 这只是一个模板实例
        var serie = {
          name: "Line 1",
          type: "line",
          stack: "Total",
          smooth: true,
          lineStyle: {
            width: 0,
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.8,
          },
          emphasis: {
            focus: "series",
          },
          data: [140, 232, 101, 264, 90, 340, 250],
        };
        //这里才是正式开始插入数据
        // 每个配置项的 name 就是对应之前所说的每条曲线的标记
        serie.name = idData[i];
        serie.data = MyData[i + 1];
        // 将配置对象加入到配置对象数组中
        series.push(serie);
      }

      if (chart) {
        const myChart = this.$echarts.init(chart);
        const option = {
          color: ["#80FFA5", "#00DDFF", "#37A2FF", "#FF0087", "#FFBF00"],
          title: {
            text: "Chart",
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "cross",
              label: {
                backgroundColor: "#6a7985",
              },
            },
          },
          legend: {
            data: idData, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
          },
          toolbox: {
            feature: {
              saveAsImage: {},
              dataZoom: {},
              magicType: {
                type: ["line", "bar", "stack", "tiled"],
              },
            },
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true,
          },
          xAxis: [
            {
              type: "category",
              boundaryGap: false,
              data: xAxisData, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
            },
          ],
          yAxis: [
            {
              type: "value",
            },
          ],
          series: series, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
        };
        myChart.setOption(option);
        window.addEventListener("resize", function () {
          myChart.resize();
        });
      }

      // 使图表能够 响应式 调整大小
      this.$on("hook:destroyed", () => {
        window.removeEventListener("resize", function () {
          myChart.resize();
        });
      });
    },
    // 画第二个图
    // 第一张图是堆叠图，还需要一张更直观的折线图来体现不同组数据间的大小关系
    getEchartData2() {
      // 引入 echarts 还有一些前期的准备工作
      const echarts = this.$echarts;
      const chart = this.$refs.chart2;
      var MyData = this.MyData;
      var idData = this.idData;
      var xAxisData = this.xAxisData;

      // 处理完data数据发现配置项也要处理一下才行
      // 要动态的根据 data 的个数来调整配置项
      var series = [];
      const len = idData.length;
      for (let i = 0; i < len; i++) {
        // 这只是一个模板实例
        var serie = {
          name: "demo",
          data: [820, 932, 901, 934, 1290, 1330, 1320],
          type: "line",
          smooth: true,
          emphasis: {
            focus: "series",
          },
        };
        //这里才是正式开始插入数据
        // 每个配置项的 name 就是对应之前所说的每条曲线的标记
        serie.name = idData[i];
        serie.data = MyData[i + 1];
        // 将配置对象加入到配置对象数组中
        series.push(serie);
      }
      if (chart) {
        const myChart = this.$echarts.init(chart);
        var option = {
          xAxis: {
            type: "category",
            data: xAxisData, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
          },
          yAxis: {
            type: "value",
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "cross",
              label: {
                backgroundColor: "#6a7985",
              },
            },
          },
          toolbox: {
            feature: {
              saveAsImage: {},
              dataZoom: {},
              magicType: {
                type: ["line", "bar", "stack", "tiled"],
              },
            },
          },
          legend: {
            data: idData, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
          },
          series: series, // 这里便能很好的直接用上之前处理好的数据，实现图表的数据和用户上传的表格数据的绑定
        };
        myChart.setOption(option);
        window.addEventListener("resize", function () {
          myChart.resize();
        });
      }

      // 使图表能够 响应式 调整大小
      this.$on("hook:destroyed", () => {
        window.removeEventListener("resize", function () {
          myChart.resize();
        });
      });
    },
    // 处理用户上传的文件的数据使得可以用在画图
    // 思路 ： 通过遍历数据数组获取其中的 数值 数据，数字形式的数据才可以拿来画图
    // 在首页规定好要上传的文件的格式，方便生成图像，用每个数组的第一个值(比如说人名， 国家名， id)来 对应 每一条折线
    // 然后还要用第一个数组中对应 数值 的值来作为x轴的值 还要将MyData处理的能够只剩数据，方便后续在图表的配置项中使用
    possessData() {
      var MyData = this.MyData;
      console.log("MyData", MyData);
      var arrFiltered = [];
      // 遍历 excel 表格数组
      for (let i in MyData) {
        var arrTemp = [];
        // 除了第一个子数组之外的每个子数组的首项都是特征项(姓名，id，标志整体曲线)
        if (i != 0) arrTemp.push(MyData[i][0]);
        for (let j in MyData[i]) {
          if (i == 0 && !isNaN(Number(MyData[1][j]))) {
            // i 等于0时的那一个数组中全是表头类型的文字，要把它们中的表示的是数字类的表头筛选出来
            arrTemp.push(MyData[i][j]);
          } // 将数组中的每个是数字的值给筛选出来
          else if (!isNaN(Number(MyData[i][j]))) {
            arrTemp.push(MyData[i][j]);
          }
        }
        arrFiltered.push(arrTemp);
      }
      var MyData = arrFiltered;

      // Mydata还要再处理一下，才能用到x轴和其他地方
      var xAxisData = MyData[0];
      var idData = [];
      for (let i in MyData) {
        for (let j in MyData[i]) {
          if (j == 0 && i != 0) {
            // 把标志项加入了这个数组
            idData.push(MyData[i][j]);
            // 把标志项删除，剩下的都是数据，方便画图
            MyData[i].splice(0, 1);
          }
        }
      }
      // 处理完以后可以把数据都放到 vue 的 data 中，方便两个图表的绘制
      this.MyData = MyData;
      this.xAxisData = xAxisData;
      this.idData = idData;
    },
  },
  watch: {},
  created() {},
};
</script>
