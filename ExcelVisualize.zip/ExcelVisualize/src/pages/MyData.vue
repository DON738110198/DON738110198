<template>
  <div class="home">
    <el-tag>请点击下方按钮导入excel文件</el-tag>
    <div class="button_group">
      <i class="el-icon-folder-opened"></i>
      <a
        href="javascript:;"
        class="button_s my_file el-button button_s el-button--primary el-button--small"
      >
        <input
          type="file"
          class="my_input"
          @change="readFile"
          id="upload"
        />导入
      </a>
    </div>
    <!-- 导入的 excel 表格显示区 -->
    <div class="table"></div>
    <!--  -->
    <!-- 没有导入 excel 表格时的提示区 -->
    <el-empty description="请导入excel表格" v-if="isShow">
      <div class="button_group">
        <i class="el-icon-folder-opened"></i>
        <a
          href="javascript:;"
          class="button_s my_file el-button button_s el-button--primary el-button--small"
        >
          <input
            type="file"
            class="my_input"
            @change="readFile"
            id="upload"
          />导入
        </a>
      </div>
    </el-empty>
  </div>
</template>
<script>
// 引入读取xlsx的js插件
import XLSX from "xlsx";
// 引入绘制excel表格的js插件
import JEXCEL, { ISNONTEXT } from "jexcel";
import Jquery from "../js/jquery";
import jsuites from "../js/jsuites";
import Jsuites from "../js/jsuites";

export default {
  name: "MyData",
  data() {
    return {
      excelData: [], //读取到的excel⽂件内容,
      json: {}, // 读取到的文件的对象,
      arr: [],
      isShow: true, // 用来记录是否显示提示用户导入 excel 表格的内容
      isExcelNone: true, // 用来记录excelData是否为空
    };
  },
  methods: {
    readFile(e) {
      //上传⽂件后读取excel⽂件内容
      this.isShow = false;
      let file = e.target.files[0];
      const types = ["xlsx", "xls"];
      const arr = file.name.split(".");
      //判断⽂件是否为excel⽂件
      if (!types.find((item) => item === arr[arr.length - 1])) {
        this.$alert("请选择正确的文件格式", "文件格式错误", {
          confirmButtonText: "确定",
          callback: (action) => {
            this.isShow = true;
          },
        });
        return;
      }
      // 判断一下是否已经读入一个 excel 表格了，如果已经读入了就不要再读入了，会出现显示bug
      if (!this.isExcelNone) {
        this.$alert("如果需要再次导入请刷新网站", "已经导入过 Excel 文件了", {
          confirmButtonText: "确定",
        });
        return;
      }
      let reader = new FileReader();
      //启动函数
      reader.readAsBinaryString(file);
      reader.onload = (e) => {
        //workbook存放excel的所有基本信息
        let workbook = XLSX.read(e.target.result, {
          type: "binary",
          cellDates: true,
        });
        //定义sheetList中存放excel表格的sheet表，就是最下⽅的tab
        let sheetList = workbook.SheetNames;
        //读取⽂件内容，（第⼀个sheet⾥的内容）
        // range：设置从第⼏⾏开始读取内容
        let json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetList[0]], {
          range: 0,
        });
        this.json = json;
        // 用 arr 接收把 json 对象变成数组之后的数组
        // 便于后续调用jexcel 生成 excel
        let arr = this.changeObj();

        // 做提示信息
        this.$message({
          message: "导入 excel 表格成功",
          type: "success",
        });
        // 将控制能否点击数据可视化导航栏的 isDisabled 设置为 false
        this.$parent.changeIsDisabled();
        //
        var options = {
          data: arr,
          colWidths: [300, 300, 300],
        };

        // 将 excelData 是否为空改为否
        this.isExcelNone = false;
        JEXCEL(document.getElementsByClassName("table")[0], options);
        // 将 Excel 数据存入缓存中，方便后续从缓存中取出处理
        sessionStorage.setItem("MyData", JSON.stringify(arr));
      };
    },
    changeObj() {
      let json = this.json;
      let arr = [];
      // 要将 json 中的数据变成数组的形式才能方便给 jexcel 调用而生成excel表格
      for (let i in json) {
        // 遍历json数组的每一行，每一行都用一个arrSon数组装每个数据
        var arrSon = [];
        for (let j in json[i]) {
          arrSon.push(json[i][j]);
        }
        // 最后遍历完每一行后将 arrSon push进arr数组中
        arr.push(arrSon);
      }
      this.arr = arr;
      return arr;
    },
  },
};
</script>
<style lang="less" scoped>
@import "../styles/jexcel.css";
@import "../styles/jsuites.css";
// 文字样式
.text {
  font-size: 30px;
  font-weight: 1000;
}
// 按钮样式
.button_group {
  .button_s {
    width: 78px;
    margin: 5px 10px 5px 5px;
  }
  .button_m {
    width: 100px;
    margin: 5px 10px 5px 5px;
  }
  .my_file {
    position: relative;
    .my_input {
      position: absolute;
      opacity: 0;
      width: 78px;
      height: 30px;
      top: 0;
      left: 0;
    }
  }
}
// 按钮样式
</style>
