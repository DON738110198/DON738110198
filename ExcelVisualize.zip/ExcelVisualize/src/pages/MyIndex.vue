<template>
  <div>
    <el-divider></el-divider>
    <el-collapse>
      <el-collapse-item name="1">
        <template slot="title">
          <div class="title">简单介绍</div>
        </template>
        <div class="description">这是一个数据可视化的网站</div>
        <div class="description">
          你可以上传自己的Excel表格，在网页上如同在excel软件中查看表格一般，做出修改后也可以保存
        </div>
        <el-image
          style="width: 80%"
          :src="img1Src[0]"
          :preview-src-list="img1Src"
        >
        </el-image>
        <div class="description">
          可以在表格上自由的修改后单击鼠标右键选择 Save as 保存为新的文件
        </div>
        <el-image
          style="width: 80%"
          :src="img2Src[0]"
          :preview-src-list="img2Src"
        ></el-image>
        <div class="description">
          导入文件后可以在 数据可视化
          导航栏处选择饼图或者折线图和柱状图来可视化数据了
          (下图可以点击查看大图并左右切换不同图片查看)
        </div>
        <el-image
          style="width: 80%"
          :src="img3Src[0]"
          :preview-src-list="img3Src"
        ></el-image>
        <div class="description">
          下面是对于 折线图/柱状图 部分图表的功能展示<br />
          可以通过右侧的工具栏区域在折线图和柱状图之间切换，在堆叠模式和平铺模式之间切换，还可以区域缩放，保存为图片
        </div>
        <video width="80%" controls>
          <source src="../assets/video1.mp4" type="video/mp4" />
          <source src="../assets/video1.webm" type="video/webm" />
          <object data="../assets/video1.mp4" width="320" height="240">
            <embed src="../assets/video1.swf" width="320" height="240" />
          </object>
        </video>
      </el-collapse-item>
      <el-collapse-item name="2">
        <template slot="title">
          <div class="title">使用规范</div>
        </template>
        <div class="description">
          如何更好的使用数据可视化功能呢？<br />
          重中之重在于我们要调整好自己上传的excel表格的格式，上传格式规范的表格才能让可视化后的图表的效果更好
        </div>
        <el-divider></el-divider>
        <!-- 这里嵌套了一个子的折叠表 -->
        <el-collapse>
          <el-collapse-item>
            <template slot="title">
              <div class="sonTitle">对于折线图/柱状图</div>
            </template>
            <div class="description">
              想要让折线图和柱状图效果更好<br />
              折线图/柱状图这部分有两个图，第一张图更偏向于展示堆叠的效果，第二张图则偏向于可以对比不同组曲线代表的数据之间的大小关系
            </div>
            <el-image
              style="width: 80%"
              :src="img4Src[0]"
              :preview-src-list="img4Src"
            ></el-image>
            <el-image
              style="width: 80%"
              :src="img5Src[0]"
              :preview-src-list="img5Src"
            ></el-image>
            <el-image
              style="width: 80%"
              :src="img6Src[0]"
              :preview-src-list="img6Src"
            ></el-image>
            <div class="description">
              只要能够按照规范来，相信可视化出来的图表一定的令人满意的
            </div>
          </el-collapse-item>
          <el-collapse-item>
            <template slot="title">
              <div class="sonTitle">对于饼图</div>
            </template>
            <div class="description">
              想要让饼图效果更好<br />
              饼图的特色在于折线图和饼图的联动，折线图的每一个坐标都会对应出一个饼图，代表的是这组数据所对应的几个数据所组成的饼图
            </div>
            <video width="80%" controls>
              <source src="../assets/video2.mp4" type="video/mp4" />
              <source src="../assets/video2.webm" type="video/webm" />
              <object data="../assets/video2.mp4" width="320" height="240">
                <embed src="../assets/video2.swf" width="320" height="240" />
              </object>
            </video>
            <el-image
              style="width: 80%"
              :src="img7Src[0]"
              :preview-src-list="img7Src"
            ></el-image>
            <div class="description">
              如下图，导入这样的数据能够让饼图的效果更好更实际
            </div>
            <video width="80%" controls>
              <source src="../assets/video3.mp4" type="video/mp4" />
              <source src="../assets/video3.webm" type="video/webm" />
              <object data="../assets/video3.mp4" width="320" height="240">
                <embed src="../assets/video3.swf" width="320" height="240" />
              </object>
            </video>
          </el-collapse-item>
        </el-collapse>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script>
export default {
  data() {
    return {
      img1Src: ["https://pic.imgdb.cn/item/629f69ed09475431291f5fd8.png"],
      img2Src: ["https://pic.imgdb.cn/item/62a53d42094754312994123e.png"],
      img3Src: [
        "https://pic.imgdb.cn/item/62a53deb094754312994aad9.png",
        "https://pic.imgdb.cn/item/62a53ea809475431299551e3.png",
        "https://pic.imgdb.cn/item/62a53f16094754312995b50b.jpg",
      ],
      img4Src: ["https://pic.imgdb.cn/item/62a5659f0947543129c0aec4.jpg"],
      img5Src: ["https://pic.imgdb.cn/item/62a5664a0947543129c16f48.jpg"],
      img6Src: ["https://pic.imgdb.cn/item/62a5675f0947543129c2a44b.jpg"],
      img7Src: ["https://pic.imgdb.cn/item/62a575940947543129d3aedf.jpg"],
    };
  },
  methods: {},
};
</script>

<style scoped lang="less">
.title {
  font-size: xx-large;
}
.description {
  font-size: large;
}
.sonTitle {
  font-size: x-large;
}
</style>
