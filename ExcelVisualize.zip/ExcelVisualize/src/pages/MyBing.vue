<template>
  <div>
    <el-divider></el-divider>
    <div ref="chart" style="width: 100%; height: 600px"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      MyData: [],
      source: [],
      series: [],
    };
  },
  mounted() {
    // 从缓存中获取用户上传的 excel 表格的数据
    const MyData = JSON.parse(sessionStorage.getItem("MyData"));
    // 将这个数据保存到这个 vue 文件的data中
    this.MyData = MyData;
    // 先处理一下数据
    this.possessData();
    this.getEchartsData();
  },
  methods: {
    getEchartsData() {
      // 获取 echarts 以及一些前期准备
      const echarts = this.$echarts;
      const chart = this.$refs.chart;
      var MyData = this.MyData;
      var source = this.source;
      var series = this.series;

      if (chart) {
        const myChart = this.$echarts.init(chart);
        setTimeout(function () {
          var option = {
            legend: {},
            tooltip: {
              trigger: "axis",
              showContent: true,
            },
            dataset: {
              source: source,
            },
            xAxis: { type: "category" },
            yAxis: { gridIndex: 0 },
            grid: { top: "55%" },
            series: series,
          };
          myChart.on("updateAxisPointer", function (event) {
            const xAxisInfo = event.axesInfo[0];
            if (xAxisInfo) {
              const dimension = xAxisInfo.value + 1;
              myChart.setOption({
                series: {
                  id: "pie",
                  label: {
                    formatter: "{b}: {@[" + dimension + "]} ({d}%)",
                  },
                  encode: {
                    value: dimension,
                    tooltip: dimension,
                  },
                },
              });
            }
          });
          myChart.setOption(option);
        });
        window.addEventListener("resize", function () {
          myChart.resize();
        });
      }
      // 使图表能够 响应式 调整大小
      this.$on("hook:destroyed", () => {
        window.removeEventListener("resize", function () {
          myChart.resize();
        });
      });
    },

    // 这次处理数据需要的结果又和折线图需要的数据不是完全一样
    // 需要把用户提交的 excel 表格的第一列作为source的第一个子数组，作为下方折线图x坐标上的值
    // 然后 source 中的每个子数组都是每一列
    possessData() {
      var MyData = this.MyData;
      // 遍历 excel 表格数组
      var arrFiltered = [];
      for (let i in MyData) {
        var arrTemp = [];
        // 除了第一个子数组之外的每个子数组的首项都是特征项(姓名，id，标志整体曲线)
        arrTemp.push(MyData[i][0]);
        for (let j in MyData[i]) {
          if (i == 0 && !isNaN(Number(MyData[1][j]))) {
            // i 等于0时的那一个数组中全是表头类型的文字，要把它们中的表示的是数字类的表头筛选出来
            arrTemp.push(MyData[i][j]);
          } // 将数组中的每个是数字的值给筛选出来
          else if (!isNaN(Number(MyData[i][j]))) {
            arrTemp.push(MyData[i][j]);
          }
        }
        arrFiltered.push(arrTemp);
      }
      MyData = arrFiltered;

      // 现在的这个 MyData 是只有数字相关内容的表格数据
      var source = [];
      // 先获得表格的第一列元素，也就是把 MyData 的每个子数组的第一个给它取出来
      const len = MyData.length;
      var arrTemp = [];
      for (let i = 0; i < len; i++) {
        arrTemp.push(MyData[i][0]);
      }
      source.push(arrTemp);
      // 现在要先列再行的遍历 MyData 这样就能把表格每一列的数据都作为一个子数组放进 source 数组中作为子数组
      const sonLen = MyData[0].length;
      for (let j = 1; j < sonLen; j++) {
        var arrTemp = [];
        for (let i = 0; i < len; i++) {
          arrTemp.push(MyData[i][j]);
        }
        source.push(arrTemp);
      }
      // 现在的source就是处理好的能用的了

      // 还要处理的是 series 配置项
      // 也是采用拼接的方式
      var series = [];
      var serie = {
        type: "line",
        smooth: true,
        seriesLayoutBy: "row",
        emphasis: { focus: "series" },
      };
      const seriesLen = source.length - 1;
      for (let i = 0; i < seriesLen; i++) {
        series.push(serie);
      }
      // 除了几个 serie 一模一样，还有一个用来配置饼图的
      var pieSerie = {
        type: "pie",
        id: "pie",
        radius: "30%",
        center: ["50%", "25%"],
        emphasis: {
          focus: "self",
        },
        label: {
          formatter: "{b}: ({d}%)",
        },
        encode: {
          itemName: source[0][0],
          // 开始的时候加载的是哪个
          value: source[0][1],
          tooltip: source[0][1],
        },
      };
      series.push(pieSerie);
      // 将 source 和 series 放到 vue 文件的 data 中去
      this.source = source;
      this.series = series;
    },
  },
};
</script>

<style scoped lang="less"></style>
