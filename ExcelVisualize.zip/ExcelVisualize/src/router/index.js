// router/index.js
// 引用该文件用于创建应用的路由器
import VueRouter from "vue-router";
import MyData from "../pages/MyData";
import MyIndex from "../pages/MyIndex";
import MyZhe from "../pages/MyZhe";
import MyBing from "../pages/MyBing";
// 引入需要注册路由的组件
export default new VueRouter({
  routes: [
    {
      name: "MyIndex",
      path: "/MyIndex",
      component: MyIndex,
    },
    {
      name: "MyData",
      path: "/MyData",
      component: MyData,
    },
    {
      name: "MyZhe",
      path: "/MyZhe",
      component: MyZhe,
    },
    {
      name: "MyBing",
      path: "/MyBing",
      component: MyBing,
    },
  ],
});
